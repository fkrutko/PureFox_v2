# CelMusper Transport (CMT) v1.3.0 — armv7h

CMSP (Celestial Music Streaming Protocol) 接收端点二进制. 把设备变成 CelMusper 串流端点
(类似 Roon Bridge), 从局域网 CelMusper sender 收音频 bit-perfect 播到本机 ALSA 声卡.

## 目标平台 / 兼容性

- **架构**: ARMv7 EABI hard-float (glibc, interp /lib/ld-linux-armhf.so.3)
- **最低 glibc**: **2.38** (二进制最高引用 GLIBC_2.38; 目标机 glibc 必须 ≥ 此版本)
- **运行时依赖 (NEEDED)**: libasound.so.2,libcjson.so.1 libc.so.6,ld-linux-armhf.so.3
  - `libasound.so.2`  — ALSA (alsa-lib). SONAME 稳定 ABI; 编译链接到 CelMusperOS 固件 glibc 2.39 rootfs (firmware-matched)
  - `libcjson.so.1`  — cJSON 1.7.x
  - `libc.so.6` / `ld-*` — glibc ≥ 2.38
- 目标机需装 alsa-lib + cjson (libcjson). 例:
  - Debian/Ubuntu: `apt install libasound2 libcjson1`
  - Alpine (musl): **本包是 glibc 版, musl 系统不适用** — 需 musl 版另编
- 动态链接; 二进制已 strip. 无 DB / Python / web 依赖.

## 包内容

- `celmusper-transport`            armv7h 二进制 (stripped)
- `cmt.conf.example`               示例配置 (I2S DAC 在此声明)
- `CMT_deployment_guide_en.md`     部署 / 配置 / 命令行 / 内存 指南 (自包含)
- `CMT_deployment_guide_cn.md`     同上中文版
- `SHA256SUMS`                     校验文件 (`sha256sum -c SHA256SUMS`)

## 快速上手

```sh
cp cmt.conf.example cmt.conf
# 编辑 cmt.conf: USB DAC 无需配置; I2S DAC 取消 [dac.mydac] 注释并填真实设备
./celmusper-transport --config cmt.conf --list-cards   # 应看到你的 DAC
./celmusper-transport --config cmt.conf                # 运行; 局域网 sender 会发现它 (mDNS)
```

⚠️ **mlockall / RT 优先级**: 见 CMT_deployment_guide §4/§7. mlockall 配大 ring_buffer_mb 在低内存设备会 OOM.
