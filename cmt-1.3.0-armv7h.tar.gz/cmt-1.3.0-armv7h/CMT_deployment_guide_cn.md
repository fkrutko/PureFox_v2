# CMT (CelMusper Transport) — 部署指南(第三方)

> 面向在设备上**部署** CMT 的集成方/运维. 覆盖: 运行条件、运行依赖、内存占用、部署、`cmt.conf`、启动命令行(绑核、RT 优先级、mmap、**mlockall —— 务必读内存警告**).
> 英文版: [`CMT_deployment_guide_en.md`](CMT_deployment_guide_en.md).

---

## 1. 你在部署什么

`celmusper-transport`(CMT)是一个**独立自包含的 Linux 二进制**, 通过网络接收 CelMusper(CMSP)音频流, bit-perfect 播放到本机 ALSA 声卡(USB DAC 或 I2S DAC). 它是音频端点; 局域网内的 CelMusper **sender** 把音频推给它.

## 2. 运行条件

| 条件 | 说明 |
|---|---|
| **操作系统** | 带 ALSA 的 Linux. 必须有 `/proc/asound`(procfs 已挂载). |
| **声卡驱动** | 你的 DAC 的内核驱动已加载并暴露 ALSA PCM(`hw:...`). USB DAC: `snd-usb-audio`. I2S: 你的 soc/codec ASoC 驱动. |
| **网络** | sender 在同一局域网可达. CMT 监听一个 **TCP** 控制端口(默认 5700 / 可配 / OS 随机)+ 一个 **UDP** 音频端口. 用 mDNS/Avahi 让 sender 自动发现端点. |
| **权限(重要)** | **RT 调度(`--rt_priority`, SCHED_FIFO)和 `--mlockall` 需要权限** —— 以 **root** 运行, 或授予 `CAP_SYS_NICE` + 提高 `RLIMIT_MEMLOCK`. 无权限则这些选项失败(或 CMT 无 RT 运行, 高负载下有断音风险). |

## 3. 运行依赖

CMT 运行时链接的共享库(按发行版安装 / 打进镜像):

- **alsa-lib**(`libasound`)—— ALSA 输出
- **libcjson** —— CMSP 控制帧 JSON
- **pthread**、**rt**、**libc** —— 标准
- **avahi**(运行时)—— mDNS 注册供发现(可选但推荐; 无它 sender 无法自动找到端点)

无数据库、无 Python、无 web 服务器. CMT 刻意保持依赖极少, 便于嵌入式目标(NT3 ARMv7h buildroot 及通用发行版).

## 4. 内存占用  ⚠️ 用 `--mlockall` 前必读

CMT 内存分三部分:

| 部分 | 大小 | 说明 |
|---|---|---|
| **进程 RSS(基础)** | ~5–10 MB | 二进制 + `libasound`/`libc`/`libcjson` 实际触及的页 |
| **应用 ring buffer** | `ring_buffer_mb`(默认 **8 MiB**) | ALSA 喂料 cache. 可配 1–256 MiB |
| **内核 UDP 接收缓冲** | 最高 **70 MiB**(固定, 不可配) | 内核 socket 内存, 不是进程 RSS. 仅在持续高码率(如 DSD512)时填满. 低内存设备要给它预留 |

所以一台正在串流的 CMT 大致用 **RSS ~10–18 MB(默认 8 MiB ring)+ 最高 70 MiB 内核 socket 缓冲**.

### ⚠️ `--mlockall` 与 OOM —— 切勿滥用

`--mlockall` 把**整个进程地址空间**锁进 RAM(`MCL_CURRENT | MCL_FUTURE`), 任何页都不会被换出 —— 这能防止缺页导致的断音, 对实时音频有益. **但每一个被锁的页都是永远无法回收的 RAM.**

**被锁的内存** ≈ 进程 RSS = **基础(~5–10 MB)+ `ring_buffer_mb`**.(那 70 MiB 内核 UDP 缓冲**不**被 mlockall 锁 —— 它是内核 socket 内存.)

**陷阱**: 如果你把 `ring_buffer_mb` 设很大(最高 256 MiB)**再**开 `mlockall`, 就钉住了那么多不可换出的 RAM. 在内存受限设备(如 256–512 MB 的 ARM 板, 或共享主机)上, 这会饿死内核和其它进程 → **OOM killer 出手**.

**规则**:
- `mlockall` **默认 `false`**(对容器 / 低内存友好). 只在**有充足 RAM 的专用音频设备**上开.
- 用 `mlockall` 时 **`ring_buffer_mb` 保持小**(默认 8 MiB 对绝大多数场景就对). **不要**把 ring 调大**又**锁它.
- 估算规则: 锁定 RAM ≈ `ring_buffer_mb` + ~10 MB. 让它是**总 RAM 的一小部分**, 给内核(含那 ~70 MiB UDP 缓冲)和其它服务留足余量.
- 如果你控制不了设备的内存预算, **就让 `mlockall = false`** —— 现代内核在轻载端点上很少会把音频页缺页严重到影响听感.

## 5. 部署 CMT

1. **放二进制**到设备任意位置(如 `/usr/local/bin/celmusper-transport`).
2. **放 `cmt.conf`** 到 `/etc/celmusper_transport/cmt.conf`(默认), 或用 `--config PATH` 指定. 无文件合法(全内置默认); 格式错则 CMT **立即报错退出**(不静默兜底).
3. **运行** —— 二选一:
   - **前台**(systemd `Type=simple`、Docker PID 1): `celmusper-transport --config /etc/celmusper_transport/cmt.conf`
   - **daemon**: `celmusper-transport --config ... --daemon --pidfile /run/cmt.pid`
4. **Docker 提示**: 用 **host 网络**(`--network host`)让 mDNS 发现和 UDP 音频路径跨容器可用; 加 `--device /dev/snd` 给声卡; 若用 RT 优先级 / mlockall 再加 `--cap-add SYS_NICE` + `--ulimit memlock`.

## 6. 配置 `cmt.conf`

INI 格式. 运维常动的段:

```ini
[server]
ctl_port = 5700                # TCP 控制端口 (0 = OS 选; 走 mDNS 通告)
transport_name = Living Room   # 给 sender / 日志显示的名字

[audio]
sink        = alsa             # alsa | mock (mock = 不出声, 调试用)
mmap        = true             # ALSA mmap 访问
realtime    = true             # 输出线程 RT 调度
rt_priority = 85               # SCHED_FIFO 优先级 1–99 (需权限)
mlockall    = false            # 锁内存 —— 开启前看 §4 警告
cpu_core    = -1               # 输出线程绑核; -1 = 不绑
ring_buffer_mb = 8             # ALSA 喂料 cache (1–256); mlockall=true 时保持小
prebuffer_ms   = 500           # 起播缓冲门槛
```

> 任何 `[audio]` 改动**重启**才生效(启动时只读一次). CLI flag 覆盖 `cmt.conf`.

### DAC 配置

**USB DAC —— 无需配置.** 插上即被 CMT 自动枚举. 用 `--list-cards` 验证.

**I2S / 非 USB DAC —— 必须声明.** I2S / 板载原生声卡无法自动探测(它们没有 USB 身份), 每一块都要在 `[dac.*]` 段声明:

```ini
[dac.mydac]
alsa_device = hw:CARD=mydac,DEV=0   # 播放实际 open 的 ALSA 设备 (必填)
vid = 0000                           # 保留号 —— 必须 0000 (必填)
pid = 0001                           # 你自分配的 id, 跨所有 [dac.*] 唯一 (必填)
name = My I2S DAC                    # 显示名 (必填)
channels = 2                         # 目前仅支持 2 (立体声), 后续扩展多声道 (必填)
altset = DSD_U32_BE:22579200         # FORMAT:MAX_RATE, 一行一个, 至少一个
altset = PCM_S32_LE:768000
altset = PCM_S24_3LE:768000
altset = PCM_S16_LE:768000
```

| 字段 | 必填 | 说明 |
|---|---|---|
| `alsa_device` | ✅ | CMT 播放时 open 的 ALSA 设备. 用稳定的 `hw:CARD=<id>[,DEV=N]` 形式(`<id>` 在 `/proc/asound/cards` 里查), 或 `hw:<N>[,<D>]`. |
| `vid` | ✅ | **必须 `0000`** —— 声明 / I2S DAC 的保留号. 真 USB DAC 从不用 vid 0000, 所以声明 DAC 永不跟它撞. |
| `pid` | ✅ | 你自选的 hex id; **跨所有 `[dac.*]` 段唯一**. |
| `name` | ✅ | 给用户看的名字(≤ 63 字符). |
| `channels` | ✅ | **当前必须为 `2`**(立体声). 多声道待后续版本扩展; 现在填其它值 CMT 会拒绝. |
| `altset` | ✅(≥1) | 一行一个能力, `FORMAT:MAX_RATE`. FORMAT ∈ {`PCM_S16_LE`、`PCM_S24_3LE`、`PCM_S32_LE`、`PCM_FLOAT`、`DSD_U8`、`DSD_U16_LE`、`DSD_U16_BE`、`DSD_U32_LE`、`DSD_U32_BE`}. MAX_RATE = PCM Hz, 或 **DSD raw bitrate**(DSD512 = 22579200). **只声明硬件真实支持的.** |

任一处填错 CMT 都会**报错退出**(缺字段 / `vid≠0000` / altset 非法 / `pid` 重复 / `alsa_device` 找不到). 然后验证 —— 你的 DAC 显示 `[declared/non-USB]`:
```bash
celmusper-transport --config <你的.conf> --list-cards
```

**为什么是声明而非自动探测?** 自动扫所有声卡会把板载主板音频、HDMI 输出也算进来(它们同样没有 USB 身份). 你确切知道哪块是自己的 DAC, 就声明它 —— 保持端点 DAC 列表干净.

## 7. 启动命令行 —— 音频调优 flag

CLI 覆盖 `cmt.conf`. 四个 RT 音频旋钮:

| Flag | cmt.conf 字段 | 含义 | 备注 / 权限 |
|---|---|---|---|
| `--cpu_core N` | `cpu_core` | **把 ALSA 输出线程绑到 CPU 核 N**(如隔离核), 削减调度抖动. `-1` = 不绑. | 绑一个不被 IRQ / 其它任务占的核效果最好. |
| `--rt_priority N` | `rt_priority` | 输出线程的 **SCHED_FIFO 实时优先级** 1–99(默认 85), 让音频抢占其它任务. | **需 root 或 `CAP_SYS_NICE`.** 跟 `--no_wait` 互斥. |
| `--mmap true\|false` | `mmap` | 用 ALSA **mmap** 访问(写入开销更低). | 大多数现代 DAC 驱动支持. |
| `--mlockall true\|false` | `mlockall` | **把进程内存锁进 RAM**(不换出), 避免缺页断音. | **需权限(RLIMIT_MEMLOCK).** ⚠️ **看 §4 —— 滥用(尤其配大 `ring_buffer_mb`)会在低内存设备 OOM.** |

相关: `--ring_buffer_mb N`、`--prebuffer_ms N`、以及 `--no_wait`(SCHED_OTHER + busy-poll —— 一核 100% 空转, 消除调度唤醒抖动; **跟 `--rt_priority` 互斥**; 仅用于专用高端 appliance).

### 推荐档位

- **专用音频 appliance, RAM 充足**(典型 Hi-End 端点):
  ```
  celmusper-transport --config cmt.conf --rt_priority 85 --mmap true --mlockall true --cpu_core <隔离核>
  ```
- **受限 / 共享设备 / 容器**(安全默认):
  ```
  celmusper-transport --config cmt.conf --rt_priority 85 --mmap true
  ```
  (`mlockall` 保持关; `ring_buffer_mb` 保持 8)
- **无权限**: 去掉 `--rt_priority`/`--mlockall`; CMT 照样能播, 只是无 RT 保证.

## 8. 验证 & 排障

```bash
celmusper-transport --version
celmusper-transport --config /etc/celmusper_transport/cmt.conf --list-cards   # 你的 DAC 应被列出
celmusper-transport --config /etc/celmusper_transport/cmt.conf                # 运行; 局域网 sender 应能发现它
```

- **DAC 没列出** → USB: 查它在 `/proc/asound/cards` 里. I2S: 必须用 `[dac.*]` 段声明(§6"DAC 配置").
- **`--rt_priority` / `--mlockall` 报错** → 以 root 运行或授予 `CAP_SYS_NICE` / 提高 `RLIMIT_MEMLOCK`.
- **OOM / 设备卡顿** → 多半是开了 `mlockall` 又配了大 `ring_buffer_mb`; 见 §4. 调小 ring 或关 mlockall.
- **sender 找不到端点** → 确认 `avahi-daemon` 在跑、mDNS 未被拦(Docker: 用 host 网络).
