# CMT (CelMusper Transport) — Deployment Guide (Third-Party)

> For integrators / operators **deploying** CMT on a device. Covers: runtime requirements, dependencies, memory footprint, deployment, `cmt.conf`, and the startup command line (CPU-core pinning, RT priority, mmap, **mlockall — read the memory warning**).
> Chinese version: [`CMT_deployment_guide_cn.md`](CMT_deployment_guide_cn.md).

---

## 1. What you are deploying

`celmusper-transport` (CMT) is a **single self-contained Linux binary** that receives a CelMusper (CMSP) audio stream over the network and plays it bit-perfect to a local ALSA sound card (USB DAC or I2S DAC). It is the audio endpoint; a CelMusper **sender** on your LAN pushes the audio to it.

## 2. Runtime requirements

| Requirement | Detail |
|---|---|
| **OS** | Linux with ALSA. `/proc/asound` must be present (procfs mounted). |
| **Sound card driver** | The kernel driver for your DAC must be loaded and expose an ALSA PCM (`hw:...`). USB DACs: `snd-usb-audio`. I2S: your soc/codec ASoC driver. |
| **Network** | Reachable from the sender on the same LAN. CMT listens on a **TCP** control port (default 5700 / configurable / OS-ephemeral) and a **UDP** audio port. mDNS/Avahi is used so senders auto-discover the endpoint. |
| **Privileges (important)** | **RT scheduling (`--rt_priority`, SCHED_FIFO) and `--mlockall` require privilege** — run CMT as **root**, or grant `CAP_SYS_NICE` and raise `RLIMIT_MEMLOCK`. Without privilege these options fail (or CMT runs without RT, risking audio dropouts under load). |

## 3. Runtime dependencies

Shared libraries CMT links at runtime (install via your distro / include in your image):

- **alsa-lib** (`libasound`) — ALSA output
- **libcjson** — CMSP control-frame JSON
- **pthread**, **rt**, **libc** — standard
- **avahi** (runtime) — mDNS registration for discovery (optional but recommended; without it senders can't auto-find the endpoint)

No database, no Python, no web server. CMT is deliberately dependency-light for embedded targets (NT3 ARMv7h buildroot and general distros).

## 4. Memory footprint  ⚠️ read before using `--mlockall`

CMT's memory has three parts:

| Part | Size | Notes |
|---|---|---|
| **Process RSS (base)** | ~5–10 MB | Binary + touched pages of `libasound`/`libc`/`libcjson`. |
| **App ring buffer** | `ring_buffer_mb` (default **8 MiB**) | ALSA feed cache. Configurable 1–256 MiB. |
| **Kernel UDP receive buffer** | up to **70 MiB** (fixed, not configurable) | Kernel socket memory, not process RSS. Fills only under sustained high-bitrate streaming (e.g. DSD512). Budget for it on low-RAM devices. |

So a streaming CMT uses roughly **RSS ~10–18 MB (with default 8 MiB ring) + up to 70 MiB kernel socket buffer**.

### ⚠️ `--mlockall` and OOM — do not abuse

`--mlockall` locks the **entire process address space** into RAM (`MCL_CURRENT | MCL_FUTURE`) so no page can be swapped out — this prevents page-fault-induced audio dropouts and is good for real-time audio. **But every locked page is RAM that can never be reclaimed.**

**What gets locked** ≈ process RSS = **base (~5–10 MB) + `ring_buffer_mb`**. (The 70 MiB kernel UDP buffer is *not* locked by mlockall — it is kernel socket memory.)

**The trap**: if you set a large `ring_buffer_mb` (up to 256 MiB) **and** enable `mlockall`, you pin that much unswappable RAM. On a memory-constrained device (e.g. a 256–512 MB ARM board or a shared host), this can starve the kernel and other processes → **the OOM killer strikes**.

**Rules**:
- `mlockall` **defaults to `false`** (container / low-memory friendly). Only enable it on a **dedicated audio device with adequate RAM**.
- **Keep `ring_buffer_mb` small** (the default 8 MiB is right for almost everyone) when using `mlockall`. Do **not** crank the ring up *and* lock it.
- Sizing rule: locked RAM ≈ `ring_buffer_mb` + ~10 MB. Keep that a **small fraction of total RAM**, leaving ample headroom for the kernel (incl. the ~70 MiB UDP buffer) and any other services.
- If you don't control the device's RAM budget, **leave `mlockall = false`** — modern kernels rarely fault audio pages badly enough to matter on a lightly-loaded endpoint.

## 5. Deploying CMT

1. **Install the binary** anywhere on the device (e.g. `/usr/local/bin/celmusper-transport`).
2. **Place `cmt.conf`** at `/etc/celmusper_transport/cmt.conf` (default), or point to it with `--config PATH`. A missing file is valid (all built-in defaults); a malformed file makes CMT **exit immediately with an error** (no silent fallback).
3. **Run it** — pick one:
   - **Foreground** (systemd `Type=simple`, Docker PID 1): `celmusper-transport --config /etc/celmusper_transport/cmt.conf`
   - **Daemon**: `celmusper-transport --config ... --daemon --pidfile /run/cmt.pid`
4. **Docker note**: run with **host networking** (`--network host`) so mDNS discovery and the UDP audio path work across containers; grant `--device /dev/snd` for the sound card, and `--cap-add SYS_NICE` + `--ulimit memlock` if you use RT priority / mlockall.

## 6. Configuring `cmt.conf`

INI format. Sections most operators touch:

```ini
[server]
ctl_port = 5700                # TCP control port (0 = OS picks; advertised via mDNS)
transport_name = Living Room   # name shown to senders / in logs

[audio]
sink        = alsa             # alsa | mock (mock = no sound, for bring-up)
mmap        = true             # ALSA mmap access
realtime    = true             # RT scheduling on the output thread
rt_priority = 85               # SCHED_FIFO priority 1–99 (needs privilege)
mlockall    = false            # lock memory — SEE §4 warning before enabling
cpu_core    = -1               # pin output thread to a CPU core; -1 = no pin
ring_buffer_mb = 8             # ALSA feed cache (1–256); keep small if mlockall=true
prebuffer_ms   = 500           # start-of-play buffering threshold
```

> Any `[audio]` change takes effect only on **restart** (read once at startup). CLI flags override `cmt.conf`.

### DAC configuration

**USB DAC — no configuration needed.** Plug it in and CMT enumerates it automatically. Verify with `--list-cards`.

**I2S / non-USB DAC — you must declare it.** I2S / native on-board sound cards cannot be auto-detected (they have no USB identity), so declare each one in a `[dac.*]` block:

```ini
[dac.mydac]
alsa_device = hw:CARD=mydac,DEV=0   # the ALSA device to open for playback (required)
vid = 0000                           # RESERVED marker — must be 0000 (required)
pid = 0001                           # your own id, unique across all [dac.*] (required)
name = My I2S DAC                    # display name (required)
channels = 2                         # currently 2 (stereo) only; multichannel planned (required)
altset = DSD_U32_BE:22579200         # FORMAT:MAX_RATE, one per line, at least one
altset = PCM_S32_LE:768000
altset = PCM_S24_3LE:768000
altset = PCM_S16_LE:768000
```

| Field | Required | Detail |
|---|---|---|
| `alsa_device` | ✅ | The ALSA device CMT opens for playback. Use the stable `hw:CARD=<id>[,DEV=N]` form (find `<id>` in `/proc/asound/cards`), or `hw:<N>[,<D>]`. |
| `vid` | ✅ | **Must be `0000`** — the reserved marker for a declared / I2S DAC. Real USB DACs never use vid 0000, so declared DACs never clash with them. |
| `pid` | ✅ | Any hex id you assign; **unique across all `[dac.*]` blocks**. |
| `name` | ✅ | Name shown to the user (≤ 63 chars). |
| `channels` | ✅ | **Currently must be `2`** (stereo). Multichannel is planned for a later version; CMT rejects any other value today. |
| `altset` | ✅ (≥1) | One capability per line, `FORMAT:MAX_RATE`. FORMAT ∈ {`PCM_S16_LE`, `PCM_S24_3LE`, `PCM_S32_LE`, `PCM_FLOAT`, `DSD_U8`, `DSD_U16_LE`, `DSD_U16_BE`, `DSD_U32_LE`, `DSD_U32_BE`}. MAX_RATE = PCM Hz, or **DSD raw bitrate** (DSD512 = 22579200). **Declare only what your hardware actually supports.** |

Any mistake makes CMT **exit with a clear error** (missing field / `vid≠0000` / bad altset / duplicate `pid` / `alsa_device` not found). Then verify — your DAC shows `[declared/non-USB]`:
```bash
celmusper-transport --config <your.conf> --list-cards
```

**Why declare instead of auto-detect?** Auto-scanning every sound card would also pick up on-board motherboard audio and HDMI outputs (they have no USB identity either). You know exactly which card is your DAC, so you declare it — this keeps the endpoint's DAC list clean.

## 7. Startup command line — audio tuning flags

CLI overrides `cmt.conf`. The four RT-audio knobs:

| Flag | cmt.conf field | Meaning | Notes / privilege |
|---|---|---|---|
| `--cpu_core N` | `cpu_core` | **Pin the ALSA output thread to CPU core N** (e.g. an isolated core) to cut scheduler jitter. `-1` = no pinning. | Give it a core not busy with IRQs/other work for best results. |
| `--rt_priority N` | `rt_priority` | **SCHED_FIFO real-time priority** 1–99 (default 85) for the output thread, so audio preempts other work. | **Needs root or `CAP_SYS_NICE`.** Mutually exclusive with `--no_wait`. |
| `--mmap true\|false` | `mmap` | Use ALSA **mmap** access (lower-overhead writes). | Most modern DAC drivers support it. |
| `--mlockall true\|false` | `mlockall` | **Lock process memory into RAM** (no swap) to avoid page-fault dropouts. | **Needs privilege (RLIMIT_MEMLOCK).** ⚠️ **Read §4 — abusing this (esp. with a large `ring_buffer_mb`) causes OOM on low-RAM devices.** |

Related: `--ring_buffer_mb N`, `--prebuffer_ms N`, and `--no_wait` (SCHED_OTHER + busy-poll — burns one CPU core at 100 %, eliminates scheduler wake-up jitter; **mutually exclusive with `--rt_priority`**; only for a dedicated high-end appliance).

### Recommended profiles

- **Dedicated audio appliance, ample RAM** (typical Hi-End endpoint):
  ```
  celmusper-transport --config cmt.conf --rt_priority 85 --mmap true --mlockall true --cpu_core <isolated core>
  ```
- **Constrained / shared device / container** (safe default):
  ```
  celmusper-transport --config cmt.conf --rt_priority 85 --mmap true
  ```
  (leave `mlockall` off; keep `ring_buffer_mb` at 8)
- **No privilege available**: omit `--rt_priority`/`--mlockall`; CMT still plays, just without RT guarantees.

## 8. Verify & troubleshoot

```bash
celmusper-transport --version
celmusper-transport --config /etc/celmusper_transport/cmt.conf --list-cards   # your DAC should be listed
celmusper-transport --config /etc/celmusper_transport/cmt.conf                # run; a sender on the LAN should discover it
```

- **DAC not listed** → USB: check it appears in `/proc/asound/cards`. I2S: you must declare it via a `[dac.*]` block (§6, "DAC configuration").
- **`--rt_priority` / `--mlockall` errors** → run as root or grant `CAP_SYS_NICE` / raise `RLIMIT_MEMLOCK`.
- **OOM / device sluggish** → you likely enabled `mlockall` with a large `ring_buffer_mb`; see §4. Lower the ring or disable mlockall.
- **Sender can't find the endpoint** → ensure `avahi-daemon` is running and mDNS isn't blocked (Docker: use host networking).
